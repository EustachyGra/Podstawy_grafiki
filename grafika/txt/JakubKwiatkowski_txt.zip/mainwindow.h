#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    bool isLineCrossed(QPoint l1, QPoint l2, int y);
    QPoint findCrossPoint(QPoint l1, QPoint l2, int y);
public slots:
    void on_pushButton_clicked();
    void rob();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
